Project setup guidance
1. Need to checkout or download the source code from gihub
2. Install node packages using npm install
3. Setup port and upload path in .env file
4. Start the server using npm start
5. You will see the port number on screen, open the URL http://localhost:3030 in browser
6. Upload images, add text and hit submit button
7. It will generate your desired output